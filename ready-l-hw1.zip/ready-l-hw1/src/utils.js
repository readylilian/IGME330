export const randomElement = (max) =>
{
    return Math.floor(Math.random() * max);
}